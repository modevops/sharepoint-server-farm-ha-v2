#
# Copyright="� Microsoft Corporation. All rights reserved."
#

configuration ConfigureSharePointServerHA
{

    param
    (
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$SharePointSetupUserAccountcreds,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$SharePointFarmAccountcreds,
        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$SpServicePoolManagedAccountcreds,
        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$SPWebPoolManagedAccountcreds,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$SharePointFarmPassphrasecreds,

        [parameter(Mandatory)]
        [String]$DatabaseName,

        [parameter(Mandatory)]
        [String]$AdministrationContentDatabaseName,

        [parameter(Mandatory)]
        [String]$DatabaseServer,

        [parameter(Mandatory)]
        [String]$Configuration,

        [String]$SqlAlwaysOnAvailabilityGroupName,
        [String]$sharepointWebfqdn,
        [String]$sharepointFarmName,
        [String]$contentDatabaseName,
        
        [String[]]$DatabaseNames,

        [String]$PrimaryReplica,

        [String]$SecondaryReplica,

        [System.Management.Automation.PSCredential]$SQLServiceCreds,

        [String]$DomainNetbiosName=(Get-NetBIOSName -DomainName $DomainName),

        [Int]$RetryCount=30,
        [Int]$RetryIntervalSec=60
    )

        Write-Verbose "AzureExtensionHandler loaded continuing with configuration"

        [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
        [System.Management.Automation.PSCredential ]$FarmCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($SharePointFarmAccountcreds.UserName)", $SharePointFarmAccountcreds.Password)
        [System.Management.Automation.PSCredential ]$SPsetupCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($SharePointSetupUserAccountcreds.UserName)", $SharePointSetupUserAccountcreds.Password)
         [System.Management.Automation.PSCredential ]$ServicePoolCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($SpServicePoolManagedAccountcreds.UserName)", $SpServicePoolAccountcreds.Password)
          [System.Management.Automation.PSCredential ]$WebPoolCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($SPWebPoolManagedAccountcreds.UserName)", $SPWebPoolManagedAccountcreds.Password)
        [System.Management.Automation.PSCredential]$SQLCreds = New-Object System.Management.Automation.PSCredential ("${DomainNetbiosName}\$($SQLServiceCreds.UserName)", $SQLServiceCreds.Password)

        

        Import-DscResource -ModuleName  Import-DscResource -ModuleName xComputerManagement, xActiveDirectory, SharePointDSC

        Node localhost
        {

            LocalConfigurationManager
            {
                RebootNodeIfNeeded = $true
            }

            xWaitForADDomain DscForestWait
            {
                DomainName = $DomainName
                DomainUserCredential= $DomainCreds
                RetryCount = $RetryCount
                RetryIntervalSec = $RetryIntervalSec
            }

            xComputer DomainJoin
            {
                Name = $env:COMPUTERNAME
                DomainName = $DomainName
                Credential = $DomainCreds
                DependsOn = "[xWaitForADDomain]DscForestWait"
            }

            Group AddSetupUserAccountToLocalAdminsGroup
            {
                GroupName = "Administrators"
                Credential = $DomainCreds
                MembersToInclude = "${DomainName}\$($SharePointSetupUserAccountcreds.UserName)"
                Ensure="Present"
                DependsOn = "[xComputer]DomainJoin"
            }
            Group AddSetupUserAccountToLocalAdminsGroupSPPool
            {
                GroupName = "Administrators"
                Credential = $DomainCreds
                MembersToInclude = "${DomainName}\$($SpServicePoolManagedAccountcreds.UserName)"
                Ensure="Present"
                DependsOn = "[xComputer]DomainJoin"
            }
            Group AddSetupUserAccountToLocalAdminsGroupSPWebP
            {
                GroupName = "Administrators"
                Credential = $DomainCreds
                MembersToInclude = "${DomainName}\$($SPWebPoolManagedAccountcreds.UserName)"
                Ensure="Present"
                DependsOn = "[xComputer]DomainJoin"
            }

            xADUser CreateFarmAccount
            {
                DomainAdministratorCredential = $DomainCreds
                DomainName = $DomainName
                UserName = $SharePointFarmAccountcreds.UserName
                Password =$FarmCreds
                Ensure = "Present"
                DependsOn = "[xComputer]DomainJoin"
            }
             xADUser createSPPOOL
            {
                DomainAdministratorCredential = $DomainCreds
                DomainName = $DomainName
                UserName = $SpServicePoolManagedAccountcreds.UserName
                Password =$ServicePoolCreds
                Ensure = "Present"
                DependsOn = "[xComputer]DomainJoin"
            }
               xADUser WebPPOOL
            {
                DomainAdministratorCredential = $DomainCreds
                DomainName = $DomainName
                UserName = $WebPoolManagedAccountcreds.UserName
                Password =$WebPoolCreds
                Ensure = "Present"
                DependsOn = "[xComputer]DomainJoin"
            }
                   

         SPCreateFarm CreateSPFarm
        {
            DatabaseServer           = $DatabaseServer
            FarmConfigDatabaseName   = $DatabaseName
            Passphrase               = $SharePointFarmPassphrasecreds
            FarmAccount              = $FarmCreds
            PsDscRunAsCredential = $SPsetupCreds
            AdminContentDatabaseName = $AdministrationContentDatabaseName
            DependsOn                = "[xADUser]CreateFarmAccount", "[Group]AddSetupUserAccountToLocalAdminsGroup"
        }
           SPManagedAccount ServicePoolManagedAccount
        {
            AccountName          = $ServicePoolCreds.UserName
            Account              = $SpServicePoolManagedAccountcreds 
            PsDscRunAsCredential = $SPsetupCreds
            DependsOn            = "[SPCreateFarm]CreateSPFarm"
        }

        SPManagedAccount WebPoolManagedAccount
        {
            AccountName          = $WebPoolCreds.UserName
            Account              = $SPWebPoolManagedAccountcreds
            PsDscRunAsCredential = $SPsetupCreds
            DependsOn            = "[SPCreateFarm]CreateSPFarm"
        }
         SPDiagnosticLoggingSettings ApplyDiagnosticLogSettings
        {
            PsDscRunAsCredential                        = $SPsetupCreds
            LogPath                                     = "C:\ULS"
            LogSpaceInGB                                = 5
            AppAnalyticsAutomaticUploadEnabled          = $false
            CustomerExperienceImprovementProgramEnabled = $true
            DaysToKeepLogs                              = 7
            DownloadErrorReportingUpdatesEnabled        = $false
            ErrorReportingAutomaticUploadEnabled        = $false
            ErrorReportingEnabled                       = $false
            EventLogFloodProtectionEnabled              = $true
            EventLogFloodProtectionNotifyInterval       = 5
            EventLogFloodProtectionQuietPeriod          = 2
            EventLogFloodProtectionThreshold            = 5
            EventLogFloodProtectionTriggerPeriod        = 2
            LogCutInterval                              = 15
            LogMaxDiskSpaceUsageEnabled                 = $true
            ScriptErrorReportingDelay                   = 30
            ScriptErrorReportingEnabled                 = $true
            ScriptErrorReportingRequireAuth             = $true
            DependsOn                                   = "[SPCreateFarm]CreateSPFarm"
        }
        SPUsageApplication UsageApplication 
        {
            Name                  = "Usage Service Application"
            DatabaseName          = "SP_Usage"
            UsageLogCutTime       = 5
            UsageLogLocation      = "C:\UsageLogs"
            UsageLogMaxFileSizeKB = 1024
            PsDscRunAsCredential = $SPsetupCreds
            DependsOn             = "[SPCreateFarm]CreateSPFarm"
        }
        SPStateServiceApp StateServiceApp
        {
            Name                 = "State Service Application"
            DatabaseName         = "SP_State"
            PsDscRunAsCredential = $SPsetupCreds
            DependsOn            = "[SPCreateFarm]CreateSPFarm"
        }
        SPDistributedCacheService EnableDistributedCache
        {
            Name                 = "AppFabricCachingService"
            Ensure               = "Present"
            CacheSizeInMB        = 1024
            ServiceAccount       = $ServicePoolCreds.UserName
            PsDscRunAsCredential = $SPsetupCreds
            CreateFirewallRules  = $true
            DependsOn            = @('[SPCreateFarm]CreateSPFarm','[SPManagedAccount]ServicePoolManagedAccount')
        }

   SPWebApplication SharePointSites
        {
            Name                   = "SharePoint Sites"
            ApplicationPool        = "SharePoint Sites"
            ApplicationPoolAccount = $SPWebPoolManagedAccount.UserName
            AllowAnonymous         = $false
            AuthenticationMethod   = "NTLM"
            DatabaseName           = "SP_Content"
            Url                    = $fqdn
            Port                   = 80
            PsDscRunAsCredential   = $SPsetupCreds
            DependsOn              = "[SPManagedAccount]WebPoolManagedAccount"
        }
        
        

  SPServiceInstance ClaimsToWindowsTokenServiceInstance
        {  
            Name                 = "Claims to Windows Token Service"
            Ensure               = "Present"
            PsDscRunAsCredential = $SPsetupCreds
            DependsOn            = "[SPCreateFarm]CreateSPFarm"
        }   

        SPServiceInstance SecureStoreServiceInstance
        {  
            Name                 = "Secure Store Service"
            Ensure               = "Present"
            PsDscRunAsCredential = $SPsetupCreds
            DependsOn            = "[SPCreateFarm]CreateSPFarm"
        }
        
        SPServiceInstance SearchServiceInstance
        {  
            Name                 = "SharePoint Server Search"
            Ensure               = "Present"
            PsDscRunAsCredential = $SPsetupCreds
            DependsOn            = "[SPCreateFarm]CreateSPFarm"
        }
        
        #**********************************************************
        # Service applications
        #
        # This section creates service applications and required
        # dependencies
        #**********************************************************

        $serviceAppPoolName = "SharePoint Service Applications"
        SPServiceAppPool MainServiceAppPool
        {
            Name                 = $serviceAppPoolName
            ServiceAccount       = $ServicePoolCreds.UserName
            PsDscRunAsCredential = $SPsetupCreds
            DependsOn            = "[SPCreateFarm]CreateSPFarm"
        }

        SPSecureStoreServiceApp SecureStoreServiceApp
        {
            Name                  = "Secure Store Service Application"
            ApplicationPool       = $serviceAppPoolName
            AuditingEnabled       = $true
            AuditlogMaxSize       = 30
            DatabaseName          = "SP_SecureStore"
            PsDscRunAsCredential  = $SPsetupCreds
            DependsOn             = "[SPServiceAppPool]MainServiceAppPool"
        }
        
        SPManagedMetaDataServiceApp ManagedMetadataServiceApp
        {  
            Name                 = "Managed Metadata Service Application"
            PsDscRunAsCredential = $SPsetupCreds
            ApplicationPool      = $serviceAppPoolName
            DatabaseName         = "SP_MMS"
            DependsOn            = "[SPServiceAppPool]MainServiceAppPool"
        }

        
        SPSearchServiceApp SearchServiceApp
        {  
            Name                  = "Search Service Application"
            DatabaseName          = "SP_Search"
            ApplicationPool       = $serviceAppPoolName
            PsDscRunAsCredential  = $SPsetupCreds
            DependsOn             = "[SPServiceAppPool]MainServiceAppPool"
        }
                   
        SPDatabaseAAG ConfigDBAAGContent
        {
            DatabaseName         = "SP_Content"
            AGName               =  $SqlAlwaysOnAvailabilityGroupName 
            PsDscRunAsCredential = $SPsetupCreds
             DependsOn             = "[SPWebApplication]SharePointSites"
        }
         SPDatabaseAAG ConfigDBAAGSTS
        {
            DatabaseName         = "SP_SecureStore"
            AGName               =  $SqlAlwaysOnAvailabilityGroupName             
            PsDscRunAsCredential =$SPsetupCreds
             DependsOn             = "[SPSecureStoreServiceApp]SecureStoreServiceApp"
        }
          SPDatabaseAAG ConfigDBAAGusage
        {
            DatabaseName         = "SP_Usage"
            AGName               = "$SqlAlwaysOnAvailabilityGroupName"            
            PsDscRunAsCredential = $SPsetupCreds
             DependsOn             = "[SPUsageApplication]UsageApplication"
        }
          SPDatabaseAAG ConfigDBAAGmms
        {
            DatabaseName         = "SP_MMS"
            AGName               =  $SqlAlwaysOnAvailabilityGroupName          
            PsDscRunAsCredential = $SPsetupCreds
             DependsOn             = "[SPManagedMetaDataServiceApp]ManagedMetadataServiceApp"
        }
        SPDatabaseAAG ConfigDBAAGstate
        {
            DatabaseName         = "SP_State"
            AGName               =  $SqlAlwaysOnAvailabilityGroupName            
            PsDscRunAsCredential = $SPsetupCreds
             DependsOn             = "[SPStateServiceApp]StateServiceApp"
        }
        SPDatabaseAAG Configsearch
        {
            DatabaseName         = "SP_Search"
            AGName               =  $SqlAlwaysOnAvailabilityGroupName          
            PsDscRunAsCredential = $SPsetupCreds
             DependsOn             = "[SPStateServiceApp]SearchServiceApp"
        }
        
        SPDatabaseAAG Configadmin
        {
            DatabaseName         = $AdministrationContentDatabaseName
            AGName               = $SqlAlwaysOnAvailabilityGroupName            
            PsDscRunAsCredential = $SPsetupCreds
             DependsOn             = "[SPCreateFarm]CreateSPFarm"
        }
            
        }

}
function Get-NetBIOSName
{
    [OutputType([string])]
    param(
        [string]$DomainName
    )

    if ($DomainName.Contains('.')) {
        $length=$DomainName.IndexOf('.')
        if ( $length -ge 16) {
            $length=15
        }
        return $DomainName.Substring(0,$length)
    }
    else {
        if ($DomainName.Length -gt 15) {
            return $DomainName.Substring(0,15)
        }
        else {
            return $DomainName
        }
    }
}
function DisableLoopbackCheck
{
    # See KB896861 for more information about why this is necessary.
    Write-Verbose -Message "Disabling Loopback Check ..."
    New-ItemProperty HKLM:\System\CurrentControlSet\Control\Lsa -Name 'DisableLoopbackCheck' -value '1' -PropertyType dword -Force | Out-Null
}
DisableLoopbackCheck 