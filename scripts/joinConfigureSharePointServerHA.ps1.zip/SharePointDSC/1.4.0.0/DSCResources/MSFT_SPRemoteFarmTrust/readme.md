**Description**

This resource is used to trust a remote SharePoint farm. This is used when federating 
search results between two different SharePoint farms. The technique is described at 
https://technet.microsoft.com/en-us/library/dn133749.aspx
