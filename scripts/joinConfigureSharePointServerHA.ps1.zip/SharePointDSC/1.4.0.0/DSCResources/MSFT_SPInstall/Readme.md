**Description**

This resource is used to install the SharePoint binaries. The BinaryDir parameter should 
point to the path that setup.exe is located (not to setup.exe itself). The ProductKey 
parameter is used to inject in to the configuration file and validate the license key 
during the installation process. This module depends on the prerequisites already being 
installed, which can be done through the use of SPInstallPreReqs.
